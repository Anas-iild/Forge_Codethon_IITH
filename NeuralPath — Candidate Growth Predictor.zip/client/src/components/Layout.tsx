import { Link, useLocation } from "wouter";
import { Brain, LayoutDashboard, Users, ChevronRight } from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
  breadcrumb?: { label: string; href?: string }[];
}

export default function Layout({ children, breadcrumb }: LayoutProps) {
  const [location] = useLocation();

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <aside className="w-56 flex-shrink-0 border-r border-border flex flex-col bg-[hsl(224_14%_10%)]">
        {/* Logo */}
        <div className="p-5 border-b border-border">
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
              <Brain className="w-4 h-4 text-primary" />
            </div>
            <div>
              <div className="font-display font-bold text-sm text-foreground leading-none">NeuralPath</div>
              <div className="text-[10px] text-muted-foreground leading-none mt-0.5">Growth Predictor</div>
            </div>
          </Link>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-1">
          <NavItem href="/" icon={<LayoutDashboard className="w-4 h-4" />} label="Dashboard" active={location === "/"} />
          <NavItem href="/candidate/new" icon={<Users className="w-4 h-4" />} label="Add Candidate" active={location === "/candidate/new"} />
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          <div className="text-xs text-muted-foreground/60 font-mono">LSTM · v1.0</div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        {breadcrumb && (
          <header className="h-11 flex items-center px-6 border-b border-border bg-[hsl(224_14%_10%)] gap-2">
            {breadcrumb.map((b, i) => (
              <span key={i} className="flex items-center gap-2">
                {i > 0 && <ChevronRight className="w-3 h-3 text-muted-foreground/50" />}
                {b.href ? (
                  <Link href={b.href} className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                    {b.label}
                  </Link>
                ) : (
                  <span className="text-xs text-foreground/80">{b.label}</span>
                )}
              </span>
            ))}
          </header>
        )}

        {/* Content */}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

function NavItem({ href, icon, label, active }: {
  href: string; icon: React.ReactNode; label: string; active: boolean;
}) {
  return (
    <Link href={href}>
      <div className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-all cursor-pointer ${
        active
          ? "bg-primary/15 text-primary"
          : "text-muted-foreground hover:bg-secondary hover:text-foreground"
      }`}>
        {icon}
        {label}
      </div>
    </Link>
  );
}
