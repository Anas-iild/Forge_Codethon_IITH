import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Plus, Trash2, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQueryClient } from "@tanstack/react-query";

export interface SignalMonth {
  month: number;
  performance: number;
  skillGrowth: number;
  collaboration: number;
  initiative: number;
  delivery: number;
}

interface SignalInputProps {
  candidateId: number;
  initialSignals?: SignalMonth[];
  onSaved?: () => void;
}

const SIGNAL_FIELDS: { key: keyof Omit<SignalMonth, "month">; label: string; color: string }[] = [
  { key: "performance", label: "Performance", color: "#0ea5e9" },
  { key: "skillGrowth", label: "Skill Growth", color: "#8b5cf6" },
  { key: "collaboration", label: "Collaboration", color: "#10b981" },
  { key: "initiative", label: "Initiative", color: "#f59e0b" },
  { key: "delivery", label: "Delivery", color: "#f43f5e" },
];

function emptyMonth(month: number): SignalMonth {
  return { month, performance: 60, skillGrowth: 55, collaboration: 65, initiative: 55, delivery: 60 };
}

export default function SignalInput({ candidateId, initialSignals, onSaved }: SignalInputProps) {
  const [signals, setSignals] = useState<SignalMonth[]>(
    initialSignals?.length ? initialSignals : [emptyMonth(1), emptyMonth(2), emptyMonth(3)]
  );
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const qc = useQueryClient();

  const updateSignal = (month: number, key: keyof SignalMonth, value: number) => {
    setSignals((prev) =>
      prev.map((s) => (s.month === month ? { ...s, [key]: value } : s))
    );
  };

  const addMonth = () => {
    const nextMonth = signals.length > 0 ? Math.max(...signals.map((s) => s.month)) + 1 : 1;
    setSignals((prev) => [...prev, emptyMonth(nextMonth)]);
  };

  const removeMonth = (month: number) => {
    if (signals.length <= 2) {
      toast({ title: "Minimum 2 months required", variant: "destructive" });
      return;
    }
    setSignals((prev) => prev.filter((s) => s.month !== month));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await apiRequest("POST", `./api/candidates/${candidateId}/signals`, { signals });
      qc.invalidateQueries({ queryKey: [`./api/candidates/${candidateId}/signals`] });
      toast({ title: "Signals saved", description: `${signals.length} months of data saved.` });
      onSaved?.();
    } catch (e) {
      toast({ title: "Failed to save", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Month columns */}
      <div className="overflow-x-auto">
        <div className="min-w-[560px]">
          {/* Header */}
          <div className="grid gap-2 mb-3" style={{ gridTemplateColumns: `80px repeat(${signals.length}, 1fr) 40px` }}>
            <div className="text-xs text-muted-foreground font-medium">Signal</div>
            {signals.map((s) => (
              <div key={s.month} className="flex flex-col items-center gap-1">
                <div className="text-xs font-medium text-foreground/80">Month {s.month}</div>
                <button
                  onClick={() => removeMonth(s.month)}
                  className="text-muted-foreground/40 hover:text-rose-400 transition-colors"
                  data-testid={`remove-month-${s.month}`}
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
            <div />
          </div>

          {/* Signal rows */}
          {SIGNAL_FIELDS.map((field) => (
            <div key={field.key} className="grid gap-2 mb-4 items-center"
              style={{ gridTemplateColumns: `80px repeat(${signals.length}, 1fr) 40px` }}>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: field.color }} />
                <span className="text-xs text-muted-foreground leading-tight">{field.label}</span>
              </div>
              {signals.map((s) => (
                <div key={s.month} className="space-y-1">
                  <Slider
                    min={0} max={100} step={1}
                    value={[s[field.key] as number]}
                    onValueChange={([v]) => updateSignal(s.month, field.key, v)}
                    className="w-full"
                    data-testid={`slider-${field.key}-month${s.month}`}
                  />
                  <div className="text-center font-mono text-xs text-muted-foreground">
                    {s[field.key]}
                  </div>
                </div>
              ))}
              <div />
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3 pt-2 border-t border-border">
        <Button
          variant="outline" size="sm"
          onClick={addMonth}
          data-testid="add-month-btn"
          className="gap-1.5"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Month
        </Button>
        <Button
          size="sm"
          onClick={handleSave}
          disabled={saving}
          data-testid="save-signals-btn"
          className="gap-1.5 ml-auto"
        >
          <Upload className="w-3.5 h-3.5" />
          {saving ? "Saving…" : "Save Signals"}
        </Button>
      </div>
    </div>
  );
}
