import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, Zap, TrendingUp, Target, Plus, Trash2, ArrowRight, Brain } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Candidate, Prediction } from "@shared/schema";

interface Stats {
  totalCandidates: number;
  totalPredictions: number;
  avgConfidence: number;
  avgGrowthVelocity: number;
  fastTrackCount: number;
}

const DEPT_COLORS: Record<string, string> = {
  Engineering: "bg-cyan-500/15 text-cyan-300 border-cyan-500/20",
  Product: "bg-violet-500/15 text-violet-300 border-violet-500/20",
  Design: "bg-pink-500/15 text-pink-300 border-pink-500/20",
  "Data Science": "bg-emerald-500/15 text-emerald-300 border-emerald-500/20",
  Marketing: "bg-amber-500/15 text-amber-300 border-amber-500/20",
  Sales: "bg-orange-500/15 text-orange-300 border-orange-500/20",
  Operations: "bg-blue-500/15 text-blue-300 border-blue-500/20",
  Finance: "bg-teal-500/15 text-teal-300 border-teal-500/20",
};

export default function Dashboard() {
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: candidates, isLoading: loadingCandidates } = useQuery<Candidate[]>({
    queryKey: ["./api/candidates"],
  });

  const { data: stats, isLoading: loadingStats } = useQuery<Stats>({
    queryKey: ["./api/stats"],
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `./api/candidates/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["./api/candidates"] });
      qc.invalidateQueries({ queryKey: ["./api/stats"] });
      toast({ title: "Candidate removed" });
    },
  });

  return (
    <Layout breadcrumb={[{ label: "Dashboard" }]}>
      <div className="p-6 space-y-6 max-w-6xl mx-auto">
        {/* Hero header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-display font-bold text-foreground">Candidate Pipeline</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              LSTM-powered growth trajectory prediction
            </p>
          </div>
          <Link href="/candidate/new">
            <Button size="sm" className="gap-1.5" data-testid="add-candidate-btn">
              <Plus className="w-3.5 h-3.5" />
              Add Candidate
            </Button>
          </Link>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard
            icon={<Users className="w-4 h-4 text-cyan-400" />}
            label="Candidates"
            value={loadingStats ? null : stats?.totalCandidates ?? 0}
            bg="bg-cyan-500/8"
          />
          <StatCard
            icon={<Brain className="w-4 h-4 text-violet-400" />}
            label="Predictions Run"
            value={loadingStats ? null : stats?.totalPredictions ?? 0}
            bg="bg-violet-500/8"
          />
          <StatCard
            icon={<Target className="w-4 h-4 text-emerald-400" />}
            label="Avg Confidence"
            value={loadingStats ? null : stats?.avgConfidence ? `${stats.avgConfidence}%` : "—"}
            bg="bg-emerald-500/8"
          />
          <StatCard
            icon={<Zap className="w-4 h-4 text-amber-400" />}
            label="Fast Track"
            value={loadingStats ? null : stats?.fastTrackCount ?? 0}
            sub="≤6 months"
            bg="bg-amber-500/8"
          />
        </div>

        {/* Candidates list */}
        <div>
          <h2 className="text-sm font-semibold text-foreground/80 mb-3 uppercase tracking-wider">
            Candidates
          </h2>

          {loadingCandidates ? (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full rounded-lg shimmer" />
              ))}
            </div>
          ) : candidates?.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="space-y-2">
              {candidates?.map((c) => (
                <CandidateRow
                  key={c.id}
                  candidate={c}
                  onDelete={() => deleteMutation.mutate(c.id)}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

function StatCard({ icon, label, value, sub, bg }: {
  icon: React.ReactNode; label: string; value: string | number | null; sub?: string; bg: string;
}) {
  return (
    <Card className="border-border/60" data-testid={`stat-${label.toLowerCase().replace(/ /g, '-')}`}>
      <CardContent className="p-4">
        <div className={`inline-flex p-2 rounded-lg mb-3 ${bg}`}>{icon}</div>
        <div className="text-xl font-display font-bold text-foreground">
          {value === null ? <Skeleton className="h-6 w-12 shimmer" /> : value}
        </div>
        <div className="text-xs text-muted-foreground">{label}</div>
        {sub && <div className="text-[10px] text-muted-foreground/60 mt-0.5">{sub}</div>}
      </CardContent>
    </Card>
  );
}

function CandidateRow({ candidate, onDelete }: { candidate: Candidate; onDelete: () => void }) {
  const { data: prediction } = useQuery<Prediction>({
    queryKey: [`./api/candidates/${candidate.id}/prediction`],
    retry: false,
  });

  const deptClass = DEPT_COLORS[candidate.department] ?? "bg-slate-500/15 text-slate-300 border-slate-500/20";

  return (
    <Card className="border-border/60 hover:border-primary/30 transition-colors group"
      data-testid={`candidate-row-${candidate.id}`}>
      <CardContent className="p-4 flex items-center gap-4">
        {/* Avatar */}
        <div className="w-9 h-9 rounded-full bg-primary/15 border border-primary/20 flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-bold text-primary">
            {candidate.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()}
          </span>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-sm text-foreground">{candidate.name}</span>
            <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${deptClass}`}>
              {candidate.department}
            </Badge>
          </div>
          <div className="text-xs text-muted-foreground mt-0.5 truncate">
            {candidate.currentRole} · {candidate.yearsExperience}y exp
          </div>
        </div>

        {/* Prediction badge */}
        {prediction ? (
          <div className="hidden sm:flex items-center gap-2 flex-shrink-0">
            <div className="text-right">
              <div className="text-xs font-medium text-emerald-400 truncate max-w-[160px]">
                → {prediction.predictedRole}
              </div>
              <div className="text-[10px] text-muted-foreground">
                in {prediction.timeframeMonths}m · {prediction.confidenceScore}% conf
              </div>
            </div>
          </div>
        ) : (
          <div className="hidden sm:block text-xs text-muted-foreground/40 flex-shrink-0">
            No prediction yet
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <Link href={`/candidate/${candidate.id}`}>
            <Button size="sm" variant="outline" className="gap-1.5 h-7 text-xs"
              data-testid={`view-candidate-${candidate.id}`}>
              View <ArrowRight className="w-3 h-3" />
            </Button>
          </Link>
          <button
            onClick={onDelete}
            className="text-muted-foreground/40 hover:text-rose-400 transition-colors p-1"
            data-testid={`delete-candidate-${candidate.id}`}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState() {
  return (
    <div className="border border-dashed border-border rounded-xl p-12 flex flex-col items-center justify-center text-center">
      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
        <Brain className="w-6 h-6 text-primary/60" />
      </div>
      <h3 className="text-sm font-medium text-foreground/70 mb-1">No candidates yet</h3>
      <p className="text-xs text-muted-foreground mb-4">
        Add your first candidate to run LSTM growth predictions.
      </p>
      <Link href="/candidate/new">
        <Button size="sm" className="gap-1.5">
          <Plus className="w-3.5 h-3.5" />
          Add First Candidate
        </Button>
      </Link>
    </div>
  );
}
