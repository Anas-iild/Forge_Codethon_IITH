import { useState } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Layout from "@/components/Layout";
import SignalInput, { type SignalMonth } from "@/components/SignalInput";
import ScoreRing from "@/components/ScoreRing";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  LineChart, Line, AreaChart, Area, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, ResponsiveContainer, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ReferenceLine
} from "recharts";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Brain, Zap, TrendingUp, Target, CheckCircle2, AlertTriangle, Sparkles, ChevronRight, BarChart2 } from "lucide-react";
import type { Candidate, SignalDataPoint, Prediction } from "@shared/schema";

const SIGNAL_COLORS = {
  performance: "#0ea5e9",
  skillGrowth: "#8b5cf6",
  collaboration: "#10b981",
  initiative: "#f59e0b",
  delivery: "#f43f5e",
};

interface FullPrediction extends Prediction {
  strengths: string[];
  riskFactors: string[];
  signalVelocities?: Record<string, number>;
  projectedSignals6m?: Record<string, number>;
  projectedSignals12m?: Record<string, number>;
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="custom-tooltip">
      <div className="font-medium mb-1 text-foreground">Month {label}</div>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground capitalize">{p.dataKey.replace(/([A-Z])/g, ' $1').trim()}:</span>
          <span className="font-medium">{typeof p.value === 'number' ? p.value.toFixed(1) : p.value}</span>
        </div>
      ))}
    </div>
  );
}

export default function CandidatePage() {
  const { id } = useParams<{ id: string }>();
  const candidateId = parseInt(id!);
  const { toast } = useToast();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState("signals");

  const { data: candidate, isLoading: loadingCandidate } = useQuery<Candidate>({
    queryKey: [`./api/candidates/${candidateId}`],
  });

  const { data: rawSignals, isLoading: loadingSignals } = useQuery<SignalDataPoint[]>({
    queryKey: [`./api/candidates/${candidateId}/signals`],
  });

  const { data: prediction, isLoading: loadingPrediction } = useQuery<FullPrediction>({
    queryKey: [`./api/candidates/${candidateId}/prediction`],
    retry: false,
  });

  const predictMutation = useMutation({
    mutationFn: () => apiRequest("POST", `./api/candidates/${candidateId}/predict`),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: [`./api/candidates/${candidateId}/prediction`] });
      qc.invalidateQueries({ queryKey: ["./api/stats"] });
      toast({ title: "Prediction complete", description: (data as FullPrediction).summary?.slice(0, 80) + "…" });
      setActiveTab("results");
    },
    onError: (e: any) => {
      toast({ title: "Prediction failed", description: e?.message ?? "Check signal data", variant: "destructive" });
    },
  });

  // Convert signal data for charts
  const signals: SignalMonth[] = rawSignals?.map((s) => ({
    month: s.month,
    performance: s.performance,
    skillGrowth: s.skillGrowth,
    collaboration: s.collaboration,
    initiative: s.initiative,
    delivery: s.delivery,
  })) ?? [];

  // Build chart data with projected values
  const chartData = signals.map((s) => ({ ...s, label: `M${s.month}` }));

  // Projection chart data
  const projectionData = prediction?.projectedSignals6m && prediction?.projectedSignals12m
    ? [
        ...chartData,
        {
          label: "6m Proj", month: signals.length + 1,
          ...Object.fromEntries(Object.entries(prediction.projectedSignals6m).map(([k, v]) => [
            k === 'skill_growth' ? 'skillGrowth' : k, v
          ])),
          projected: true,
        },
        {
          label: "12m Proj", month: signals.length + 2,
          ...Object.fromEntries(Object.entries(prediction.projectedSignals12m).map(([k, v]) => [
            k === 'skill_growth' ? 'skillGrowth' : k, v
          ])),
          projected: true,
        },
      ]
    : chartData;

  // Radar data — current vs projected
  const radarData = [
    { metric: "Performance", current: signals.at(-1)?.performance ?? 0, projected: prediction?.projectedSignals6m?.performance ?? 0 },
    { metric: "Skill Growth", current: signals.at(-1)?.skillGrowth ?? 0, projected: prediction?.projectedSignals6m?.skill_growth ?? 0 },
    { metric: "Collaboration", current: signals.at(-1)?.collaboration ?? 0, projected: prediction?.projectedSignals6m?.collaboration ?? 0 },
    { metric: "Initiative", current: signals.at(-1)?.initiative ?? 0, projected: prediction?.projectedSignals6m?.initiative ?? 0 },
    { metric: "Delivery", current: signals.at(-1)?.delivery ?? 0, projected: prediction?.projectedSignals6m?.delivery ?? 0 },
  ];

  const hasEnoughData = signals.length >= 2;

  if (loadingCandidate) return (
    <Layout breadcrumb={[{ label: "Dashboard", href: "/" }, { label: "Loading…" }]}>
      <div className="p-6 space-y-4">
        <Skeleton className="h-20 w-full shimmer" />
        <Skeleton className="h-64 w-full shimmer" />
      </div>
    </Layout>
  );

  if (!candidate) return (
    <Layout breadcrumb={[{ label: "Dashboard", href: "/" }, { label: "Not Found" }]}>
      <div className="p-6 text-muted-foreground">Candidate not found.</div>
    </Layout>
  );

  return (
    <Layout breadcrumb={[
      { label: "Dashboard", href: "/" },
      { label: candidate.name }
    ]}>
      <div className="p-6 space-y-6 max-w-5xl mx-auto">
        {/* Candidate header */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center flex-shrink-0">
              <span className="text-base font-bold text-primary">
                {candidate.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()}
              </span>
            </div>
            <div>
              <h1 className="text-xl font-display font-bold text-foreground">{candidate.name}</h1>
              <div className="text-sm text-muted-foreground mt-0.5">
                {candidate.currentRole} · {candidate.department} · {candidate.yearsExperience}y exp
              </div>
            </div>
          </div>

          <Button
            onClick={() => predictMutation.mutate()}
            disabled={!hasEnoughData || predictMutation.isPending}
            className="gap-2 shrink-0"
            data-testid="run-prediction-btn"
          >
            <Brain className="w-4 h-4" />
            {predictMutation.isPending ? "Running LSTM…" : "Run Prediction"}
          </Button>
        </div>

        {!hasEnoughData && (
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/8 px-4 py-3 text-sm text-amber-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            Add at least 2 months of signal data below before running a prediction.
          </div>
        )}

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-secondary/50 border border-border/60">
            <TabsTrigger value="signals" data-testid="tab-signals">Signal Input</TabsTrigger>
            <TabsTrigger value="chart" data-testid="tab-chart">Time-Series Chart</TabsTrigger>
            <TabsTrigger value="results" data-testid="tab-results" disabled={!prediction}>
              Prediction Results {prediction && <span className="ml-1.5 w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />}
            </TabsTrigger>
          </TabsList>

          {/* ── Signal Input Tab ─────────────────────────────────────── */}
          <TabsContent value="signals" className="mt-4">
            <Card className="border-border/60">
              <CardHeader className="pb-3 pt-5 px-5">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-primary" />
                  Monthly Performance Signals
                </CardTitle>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Input 0–100 scores for each signal dimension per month. The LSTM learns from trends over time.
                </p>
              </CardHeader>
              <CardContent className="px-5 pb-5">
                {loadingSignals ? (
                  <Skeleton className="h-48 shimmer" />
                ) : (
                  <SignalInput
                    candidateId={candidateId}
                    initialSignals={signals}
                    onSaved={() => {
                      qc.invalidateQueries({ queryKey: [`./api/candidates/${candidateId}/signals`] });
                    }}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── Chart Tab ────────────────────────────────────────────── */}
          <TabsContent value="chart" className="mt-4">
            <div className="space-y-4">
              <Card className="border-border/60">
                <CardHeader className="pb-2 pt-5 px-5">
                  <CardTitle className="text-sm font-semibold">Signal Trajectories</CardTitle>
                  <p className="text-xs text-muted-foreground">Historical trend + 6/12-month LSTM projection</p>
                </CardHeader>
                <CardContent className="px-5 pb-5">
                  {signals.length === 0 ? (
                    <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                      Add signal data in the Signal Input tab first.
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height={280}>
                      <AreaChart data={projectionData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                        <defs>
                          {Object.entries(SIGNAL_COLORS).map(([k, c]) => (
                            <linearGradient key={k} id={`grad-${k}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor={c} stopOpacity={0.12} />
                              <stop offset="95%" stopColor={c} stopOpacity={0} />
                            </linearGradient>
                          ))}
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(224 10% 22%)" />
                        <XAxis dataKey="label" tick={{ fontSize: 12, fill: "hsl(213 15% 68%)" }} axisLine={false} tickLine={false} />
                        <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: "hsl(213 15% 68%)" }} axisLine={false} tickLine={false} width={36} />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend wrapperStyle={{ fontSize: 12, paddingTop: 10, color: "hsl(213 15% 75%)" }} />
                        {prediction && (
                          <ReferenceLine
                            x={`M${signals.length}`}
                            stroke="hsl(213 10% 35%)"
                            strokeDasharray="4 4"
                            label={{ value: "Now", fill: "hsl(213 15% 72%)", fontSize: 11, fontWeight: 500 }}
                          />
                        )}
                        {Object.entries(SIGNAL_COLORS).map(([k, c]) => (
                          <Area key={k} type="monotone" dataKey={k}
                            stroke={c} strokeWidth={2} fill={`url(#grad-${k})`}
                            dot={{ fill: c, r: 3, strokeWidth: 0 }}
                            activeDot={{ r: 5, strokeWidth: 0 }}
                          />
                        ))}
                      </AreaChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>

              {prediction && signals.length > 0 && (
                <Card className="border-border/60">
                  <CardHeader className="pb-2 pt-5 px-5">
                    <CardTitle className="text-sm font-semibold">Capability Radar</CardTitle>
                    <p className="text-xs text-muted-foreground">Current vs. 6-month projected profile</p>
                  </CardHeader>
                  <CardContent className="px-5 pb-5">
                    <ResponsiveContainer width="100%" height={290}>
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="hsl(224 10% 26%)" />
                        <PolarAngleAxis dataKey="metric" tick={{ fontSize: 12, fill: "hsl(213 15% 75%)" }} />
                        <Radar name="Current" dataKey="current" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.15} strokeWidth={2} />
                        <Radar name="6m Projected" dataKey="projected" stroke="#10b981" fill="#10b981" fillOpacity={0.1} strokeWidth={2} strokeDasharray="4 4" />
                        <Legend wrapperStyle={{ fontSize: 12, color: "hsl(213 15% 75%)" }} />
                        <Tooltip content={<CustomTooltip />} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* ── Prediction Results Tab ───────────────────────────────── */}
          <TabsContent value="results" className="mt-4">
            {loadingPrediction ? (
              <div className="space-y-3">
                <Skeleton className="h-32 shimmer" />
                <Skeleton className="h-24 shimmer" />
              </div>
            ) : prediction ? (
              <div className="space-y-4">
                {/* Headline card */}
                <Card className="border-primary/30 bg-primary/5">
                  <CardContent className="p-5">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Sparkles className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <div className="text-xs text-primary font-semibold uppercase tracking-wider mb-1">LSTM Prediction</div>
                        <p className="text-sm text-foreground leading-relaxed">{prediction.summary}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Score rings */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Card className="border-border/60">
                    <CardContent className="p-4 flex flex-col items-center">
                      <ScoreRing score={prediction.confidenceScore} size={80} sublabel="Confidence" />
                    </CardContent>
                  </Card>
                  <Card className="border-border/60">
                    <CardContent className="p-4 flex flex-col items-center">
                      <ScoreRing score={prediction.growthVelocity} size={80} sublabel="Growth Velocity" />
                    </CardContent>
                  </Card>
                  <Card className="border-border/60">
                    <CardContent className="p-4 flex flex-col items-center">
                      <ScoreRing score={prediction.learningVelocity} size={80} sublabel="Learning Velocity" />
                    </CardContent>
                  </Card>
                  <Card className="border-border/60">
                    <CardContent className="p-4 flex flex-col items-center">
                      <ScoreRing score={prediction.roleFitScore} size={80} sublabel="Role Fit" />
                    </CardContent>
                  </Card>
                </div>

                {/* Predicted role + timeframe */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <Card className="border-border/60">
                    <CardContent className="p-5">
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Predicted Next Role</div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-8 rounded-full bg-emerald-500" />
                        <div>
                          <div className="text-base font-display font-bold text-foreground">{prediction.predictedRole}</div>
                          <div className="text-xs text-muted-foreground">from {candidate.currentRole}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="border-border/60">
                    <CardContent className="p-5">
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Estimated Timeframe</div>
                      <div className="flex items-center gap-2">
                        <div className={`w-1 h-8 rounded-full ${prediction.timeframeMonths <= 6 ? 'bg-cyan-500' : prediction.timeframeMonths <= 9 ? 'bg-amber-500' : 'bg-rose-500'}`} />
                        <div>
                          <div className="text-base font-display font-bold text-foreground">
                            {prediction.timeframeMonths} months
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {prediction.timeframeMonths <= 6 ? "Fast-track trajectory" : prediction.timeframeMonths <= 9 ? "On-track progression" : "Standard timeline"}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Strengths + Risks */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <Card className="border-emerald-500/20">
                    <CardContent className="p-5">
                      <div className="flex items-center gap-1.5 mb-3">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">Strengths</span>
                      </div>
                      <ul className="space-y-1.5">
                        {prediction.strengths.map((s, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <div className="w-1 h-1 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                            {s}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                  <Card className="border-amber-500/20">
                    <CardContent className="p-5">
                      <div className="flex items-center gap-1.5 mb-3">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Risk Factors</span>
                      </div>
                      <ul className="space-y-1.5">
                        {prediction.riskFactors.map((r, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <div className="w-1 h-1 rounded-full bg-amber-500 mt-2 flex-shrink-0" />
                            {r}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ) : (
              <div className="text-center py-16 text-muted-foreground text-sm">
                Run a prediction first using the button above.
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
