import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { UserPlus } from "lucide-react";

const DEPARTMENTS = [
  "Engineering", "Product", "Design", "Data Science",
  "Marketing", "Sales", "Operations", "Finance"
];

const ROLE_SUGGESTIONS: Record<string, string[]> = {
  Engineering: ["Junior Engineer", "Software Engineer", "Senior Engineer", "Staff Engineer"],
  Product: ["Associate PM", "Product Manager", "Senior PM", "Principal PM"],
  Design: ["Junior Designer", "Designer", "Senior Designer", "Lead Designer"],
  "Data Science": ["Data Analyst", "Data Scientist", "Senior Data Scientist"],
  Marketing: ["Marketing Associate", "Marketing Manager", "Senior Marketing Manager"],
  Sales: ["Sales Development Rep", "Account Executive", "Senior AE"],
  Operations: ["Operations Analyst", "Operations Manager"],
  Finance: ["Financial Analyst", "Senior Analyst", "Finance Manager"],
};

export default function NewCandidate() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const qc = useQueryClient();

  const [form, setForm] = useState({
    name: "",
    currentRole: "",
    department: "Engineering",
    yearsExperience: "2",
    notes: "",
  });

  const mutation = useMutation({
    mutationFn: (data: typeof form) =>
      apiRequest("POST", "./api/candidates", {
        name: data.name,
        currentRole: data.currentRole,
        department: data.department,
        yearsExperience: parseFloat(data.yearsExperience),
        notes: data.notes,
      }),
    onSuccess: (data: any) => {
      qc.invalidateQueries({ queryKey: ["./api/candidates"] });
      qc.invalidateQueries({ queryKey: ["./api/stats"] });
      toast({ title: "Candidate added", description: `${form.name} is ready for signal input.` });
      navigate(`/candidate/${data.id}`);
    },
    onError: () => toast({ title: "Failed to create candidate", variant: "destructive" }),
  });

  const roleSuggestions = ROLE_SUGGESTIONS[form.department] ?? [];

  return (
    <Layout breadcrumb={[{ label: "Dashboard", href: "/" }, { label: "New Candidate" }]}>
      <div className="p-6 max-w-xl mx-auto">
        <div className="mb-6">
          <h1 className="text-xl font-display font-bold text-foreground">Add Candidate</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Enter profile details to start tracking</p>
        </div>

        <Card className="border-border/60">
          <CardContent className="p-6 space-y-5">
            {/* Name */}
            <div className="space-y-1.5">
              <Label htmlFor="name" className="text-xs font-medium text-foreground/80">Full Name</Label>
              <Input
                id="name"
                placeholder="e.g. Priya Sharma"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                data-testid="input-name"
                className="bg-secondary/50 border-border"
              />
            </div>

            {/* Department */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-foreground/80">Department</Label>
              <Select
                value={form.department}
                onValueChange={(v) => setForm({ ...form, department: v, currentRole: "" })}
              >
                <SelectTrigger className="bg-secondary/50 border-border" data-testid="select-department">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEPARTMENTS.map((d) => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Current Role */}
            <div className="space-y-1.5">
              <Label htmlFor="role" className="text-xs font-medium text-foreground/80">Current Role</Label>
              <Input
                id="role"
                placeholder="e.g. Software Engineer"
                value={form.currentRole}
                onChange={(e) => setForm({ ...form, currentRole: e.target.value })}
                data-testid="input-role"
                className="bg-secondary/50 border-border"
                list="role-suggestions"
              />
              <datalist id="role-suggestions">
                {roleSuggestions.map((r) => <option key={r} value={r} />)}
              </datalist>
              <div className="flex flex-wrap gap-1.5 mt-1">
                {roleSuggestions.slice(0, 3).map((r) => (
                  <button
                    key={r}
                    onClick={() => setForm({ ...form, currentRole: r })}
                    className="text-[10px] px-2 py-0.5 rounded-full border border-border/60 text-muted-foreground hover:border-primary/40 hover:text-primary transition-colors"
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            {/* Years Experience */}
            <div className="space-y-1.5">
              <Label htmlFor="exp" className="text-xs font-medium text-foreground/80">Years of Experience</Label>
              <Input
                id="exp"
                type="number"
                min="0" max="40" step="0.5"
                value={form.yearsExperience}
                onChange={(e) => setForm({ ...form, yearsExperience: e.target.value })}
                data-testid="input-experience"
                className="bg-secondary/50 border-border"
              />
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <Label htmlFor="notes" className="text-xs font-medium text-foreground/80">
                Notes <span className="text-muted-foreground/60">(optional)</span>
              </Label>
              <Textarea
                id="notes"
                placeholder="Context, goals, or observations…"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                data-testid="input-notes"
                className="bg-secondary/50 border-border resize-none h-20 text-sm"
              />
            </div>

            {/* Submit */}
            <Button
              className="w-full gap-2"
              disabled={!form.name || !form.currentRole || mutation.isPending}
              onClick={() => mutation.mutate(form)}
              data-testid="submit-candidate-btn"
            >
              <UserPlus className="w-4 h-4" />
              {mutation.isPending ? "Adding…" : "Add & Configure Signals"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
