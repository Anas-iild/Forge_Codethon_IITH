import { Switch, Route, Router } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import Dashboard from "@/pages/Dashboard";
import CandidatePage from "@/pages/CandidatePage";
import NewCandidate from "@/pages/NewCandidate";
import NotFound from "@/pages/not-found";

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router hook={useHashLocation}>
        <div className="min-h-screen bg-background">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/candidate/new" component={NewCandidate} />
            <Route path="/candidate/:id" component={CandidatePage} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </Router>
      <Toaster />
    </QueryClientProvider>
  );
}
